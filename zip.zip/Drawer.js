import CartPage from "./components/Cart.js";
import ProfilePage from "./components/Profile.js";
import { createDrawerNavigator } from "@react-navigation/drawer";
import AntDesign from "react-native-vector-icons/AntDesign";
import OrderPage from "./components/OrderPage.js";
const Drawer = createDrawerNavigator();

export default function DrawerPage({route}) {
    // console.log(route.params.data)
    const user = route.params.data;
  return (
    <Drawer.Navigator>
      <Drawer.Screen
        name="Cart"
        component={CartPage}
        initialParams={{ user }}
      />
      <Drawer.Screen
        name="Profile"
        component={ProfilePage}
        initialParams={{ user }}
      />
      {/* <Drawer.Screen
        name="CartPage"
        component={CartPage}
        initialParams={{ user }}
      /> */}
    </Drawer.Navigator>
  );
}
