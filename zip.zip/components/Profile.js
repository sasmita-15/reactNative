// components/Profile.js
import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

const ProfilePage = ({ route, navigation }) => {
  const user = route.params.user;
//   console.log(user.user.username)
  

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile Page</Text>
      <Text style={styles.label}>Username:</Text>
      <Text style={styles.value}>{user.user.username}</Text>
      <Text style={styles.label}>Email:</Text>
      <Text style={styles.value}>{user.user.email}</Text>
      {/* Add more user info as needed */}
      
      <Button
        title="Go to Cart"
        onPress={() => navigation.navigate('Cart')}
      />
      <Button
        title="Logout"
        onPress={() => {
          // Handle logout logic here
          alert('Logged out');
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
  },
  value: {
    fontSize: 18,
    marginBottom: 10,
  },
});

export default ProfilePage;
