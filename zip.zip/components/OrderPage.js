import React, {useState} from "react";
import { Text, View, StyleSheet } from "react-native";

function OrderPage() {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text>Order Page</Text>
        </View>
      );
}

export default OrderPage